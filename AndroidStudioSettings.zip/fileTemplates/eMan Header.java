/**
* TODO: class description
* @author: eMan s.r.o.
*/