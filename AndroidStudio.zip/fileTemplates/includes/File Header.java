/**
 * TODO: class description
 * 
 * @author Andrej Martinák <andrej.martinak@eman.cz>
 */